require "byebug" #class PolyTreeNode
class PolyTreeNode
attr_accessor :parent, :children, :value

    def initialize(value)

        @parent = nil
        @children = []
    
        @value = value
    end

    def parent=(new_parent)
        old_parent = @parent
        if new_parent == nil
            @parent = nil

        elsif (old_parent == nil) || (new_parent != nil)
           old_parent.children.delete(self) if (@parent != nil) && (@parent.children.include?(self))   # removes node from parent's children array (?)
            @parent = new_parent
            new_parent.children << self if !(new_parent.children.include?(self))



        end

    end

    def remove_child(child) 

        raise "error" if !(@children.include?(child))

        
        @children.delete(child) if @children.include?(child)
    

         child.parent= nil
    end




    def add_child(child)
        
    
        child.parent = self
        @children << child if !(@children.include?(child))





    end
    

    # def dfs(root_node, target_value)
    #     return root_node if root_node.value == target_value
    #     return nil if ((root_node.children.empty?) && (root_node.value != target_value)) || nil
    #     root_node.children.each_with_index do |child, i|

    #         if child.value == target_value

    #             return child
    #         else


    #             child.dfs(child, target_value)
    #             # next if nil 
    #         end
        
    
    #     return nil if i == root_node.children.length - 1
    #     end

    # nil
    # end

    def dfs(target_value)

        #debugger
        # p target_value 
        return self if @value == target_value
        return nil if @children.empty?  
        #debugger



        @children.each do |child|
            #debugger

            if child.value == target_value
                return child
            else
                child.dfs(target_value)
                next if nil
            end
            #debugger
        end
    nil
    end

def inspect
    { 
    value: value, children: children.map{|node| node.value} #parent: parent

}.inspect



end









def bfs(target_value)
    return self if @value == target_value
    return nil if @children.empty?
    # debugger
    queue = [self]
    until queue.empty?
        queue.each do |queuespot|
            if queuespot.value == target_value
                # debugger

                return queuespot

            elsif queuespot.children != []
                queue << queuespot.children.flatten 
                # debugger
                break # queue.shift
            #end
            else
                break

            end


        end


        queue.shift
    end
nil
end









end